nohup java -jar StreamingGBS_core-1.0.8.jar --spring.profiles.active=prod &
